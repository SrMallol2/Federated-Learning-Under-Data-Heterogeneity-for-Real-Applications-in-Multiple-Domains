import pickle

import numpy as np
from sklearn.model_selection import train_test_split

from utils.utils import time_series_generator


class DatasetGenerator:
    def __init__(self, samples_per_ap, aps, features, train_ratio=0.7, lookback=5, steps=1, random_seed=None,
                 save_distributions=None, population_dependent=True):
        """
        Initialize the dataset for the desired phase.

        Parameters:
            samples_per_ap (int): number of samples per ap
            aps (int): number of gaussian distributions (aps) that the data will be drawn from
            features (int): number of columns in the data
            train_ratio (Union[int,float]): training dataset ratio for splitting the dataset, if it's a float
            random_seed (Union[int,None]): a random seed to make the split reproducible
            save_distributions (Boolean): should the distributions be saved
            population_dependent (Boolean): if true, the APs in the training will not be used for testing
        """
        super().__init__()
        self.lookback = lookback
        self.steps = steps
        Y, X, distributions, APs = [], [], [], []
        random_state = np.random.RandomState(seed=random_seed)
        for i in range(aps):
            # TODO: load is dependent on only the previous timestep now. We should generalized it somehow.
            y_mean, y_std = random_state.uniform(0, 1), random_state.uniform(0, 0.1)
            w = random_state.uniform(size=(1, features))
            x_mean, x_std = y_mean / np.sum(w), y_std / np.sqrt(np.sum(w ** 2))
            x = random_state.normal(x_mean, x_std, (samples_per_ap, features))
            n = random_state.normal(0, 0.01, samples_per_ap).reshape(-1, 1)
            y = np.dot(x, w.T) + n
            y = np.roll(y, 1)
            y[0] = y[1]
            Y.extend(y)
            X.extend(x)
            APs.extend([i] * samples_per_ap)
            distribution = {
                'mean': y_mean,
                'y_std': y_std,
                'w': w
            }
            distributions.extend([distribution])
        Y = np.array(Y)
        X = np.array(X)
        APs = np.array(APs)
        if save_distributions is not None:
            distributions = np.array(distributions)
            with open(save_distributions, 'wb') as output_file:
                pickle.dump({
                    'distributions': distributions,
                    'Y': Y,
                    'APs': APs
                }, output_file, pickle.HIGHEST_PROTOCOL)
        column_unique_values = list(range(aps))
        train_num = int(train_ratio)
        if population_dependent:
            if train_ratio < 1:
                train_num = int(train_ratio * len(column_unique_values))
            train_aps = np.random.choice(column_unique_values, train_num, replace=False)
            test_aps = np.setdiff1d(column_unique_values, train_aps)
            test_indices = np.isin(APs, test_aps)
            train_indices = np.isin(APs, train_aps)
        else:
            if train_ratio < 1:
                train_num = int(train_ratio * len(X))
            train_aps = column_unique_values
            test_aps = column_unique_values
            sample_indices = np.array(list(range(len(X))))
            train_indices, test_indices = [], []
            for ap in column_unique_values:
                train_indices.extend(sample_indices[APs == ap][:train_num // aps])
                test_indices.extend(sample_indices[APs == ap][train_num // aps:])

        timeseries = np.hstack((Y, X))

        not_split_train_data = transform_dataset(np.array(timeseries[train_indices]).astype(np.float32),
                                                 self.lookback,
                                                 self.steps,
                                                 APs[train_indices],
                                                 target_column=0)

        X_train, X_validation, y_train, y_validation, ap_train, ap_validation = train_test_split(
            not_split_train_data[0],
            not_split_train_data[1],
            not_split_train_data[2],
            test_size=0.2,
            random_state=random_seed)

        X_test, y_test, ap_test = transform_dataset(np.array(timeseries[test_indices]).astype(np.float32),
                                                    self.lookback,
                                                    self.steps, APs[test_indices],
                                                    target_column=0)
        print("      - APs for training/validation: " + str(train_aps))
        print("      - APs for test: " + str(test_aps))
        print("      - Training samples: " + str(len(X_train)))
        print("      - Validation samples: " + str(len(X_validation)))
        print("      - Test samples: " + str(len(X_test)))
        #
        # # STEP 3: Transform the dataset (normalization + time series creation)
        # # Transform the dataset (normalization + time series creation)
        self.X_train, self.y_train, self.ap_train = X_train, y_train, ap_train
        self.X_validation, self.y_validation, self.ap_validation = X_validation, y_validation, ap_validation
        self.X_test, self.y_test, self.ap_test = X_test, y_test, ap_test

    def getSplit(self, split):
        if split == 'train':
            return self.X_train, self.y_train, self.ap_train
        if split == 'test':
            return self.X_test, self.y_test, self.ap_test
        return self.X_validation, self.y_validation, self.ap_validation


def transform_dataset(dataset, lookback, steps, apIdColumn, target_column=None):
    # scaler = preprocessing.MinMaxScaler(feature_range=(0.0001, 1))
    # x = scaler.fit_transform(dataset)
    # y = np.digitize(dataset[:, 0], bins=[1000, 100000])
    # y = scaler.transform(dataset)
    x = np.copy(dataset)
    y = np.copy(dataset)
    unique_aps = np.unique(apIdColumn)
    x_transform, y_transform, ap_transform = [], [], []
    for ap in unique_aps:
        x_transform_ap, y_transform_ap = time_series_generator(x[apIdColumn == ap], y[apIdColumn == ap], lookback,
                                                               steps)
        ap_transform.extend([ap] * len(x_transform_ap))
        if len(x_transform) == 0:
            x_transform, y_transform = x_transform_ap, y_transform_ap
        else:
            x_transform, y_transform = np.concatenate((x_transform, x_transform_ap), axis=0), np.concatenate(
                (y_transform, y_transform_ap), axis=0)
    if target_column is None:
        return x_transform, y_transform.squeeze(), ap_transform
    return x_transform, y_transform.squeeze()[:, target_column].reshape(-1, 1), ap_transform


if __name__ == '__main__':
    dataset_generator = DatasetGenerator(10, 5, 5, train_ratio=0.7, lookback=1,
                                         steps=1, random_seed=13132112, save_distributions='./distributions.pkl',
                                         population_dependent=False)
