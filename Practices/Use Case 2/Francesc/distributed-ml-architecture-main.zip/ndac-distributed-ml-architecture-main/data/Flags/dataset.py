import sys
import random

import pandas as pd
from sklearn import preprocessing
import numpy as np
import torch

from sklearn.model_selection import train_test_split
import pickle

from utils.utils import time_series_generator


class Dataset(torch.utils.data.Dataset):
    def __init__(self, X_data, Y_data):
        super().__init__()
        self.X_data, self.Y_data = X_data, Y_data

    def __len__(self):
        """Denotes the total number of samples"""
        return len(self.Y_data)

    def __getitem__(self, index):
        """Generates one sample of data"""

        # Load data and get label
        x = torch.Tensor(self.X_data[index])
        y = torch.Tensor(self.Y_data[index])

        return {
            'x': x,
            'y': y
        }


class DatasetGenerator:
    def __init__(self, path, split_by, train_ratio=0.7, test_ratio=1, lookback=5, steps=1,
                 columns=None, random_seed=None):
        """
        Initialize the dataset for the desired phase.

        Parameters:
            path (str): path to the dataset
            split_by (str): determines the means of split for test and train. It should be a column in the dataset.
            train_ratio (Union[int,float]): training dataset ratio for splitting the dataset, if it's a float
            number, it will be used as ratio, if it is an integer it will be used as an explicit number of APs
            or TimeSteps
            lookback (int): the number of steps in the past used to predict the next step
            steps (int): number of future forecasted steps of the time series
            columns (list): columns used for prediction
            random_seed (int): a random seed to make the split reproducible
        """
        super().__init__()
        self.raw_data = raw_data = load_dataset(path=path)

        self.lookback = lookback
        self.steps = steps
        self.train_ratio = train_ratio

        if split_by not in ['AP ID', 'Index']:
            raise Exception('Only AP ID and Index are supported for data split right now.')

        if columns is None:
            columns = ['Bytes', 'day_of_week_sin', 'day_of_week_cos', 'hour_of_day_sin', 'hour_of_day_cos',
                       'Active Users']

        print(" * Total data set samples: " + str(len(raw_data)))

        # STEP 1: Split the dataset
        if split_by == 'AP ID':

            column_unique_values = np.unique(raw_data[split_by])
            train_num = int(train_ratio)
            if train_ratio < 1:
                train_num = int(train_ratio * len(column_unique_values))
            np.random.seed(random_seed)
            train_aps = np.random.choice(column_unique_values, train_num, replace=False)

            if test_ratio <= 1:
                num_aps_test = int(len(train_aps) * test_ratio)
            else:
                num_aps_test = int(min(test_ratio, len(train_aps)))
            test_set = np.setdiff1d(column_unique_values, train_aps)
            test_aps = np.random.choice(test_set, num_aps_test, replace=False)
            test_indices = raw_data[split_by].isin(test_aps)

            train_indices = raw_data[split_by].isin(train_aps)
            # The next line is commented to avoid using the entire remaining set of APs for testing
            # test_indices = ~raw_data[split_by].isin(train_aps)

            timeseries = raw_data[columns]

            # STEP 2: Split data into training and validation
            not_split_train_data = transform_dataset(np.array(timeseries[train_indices]).astype(np.float32),
                                                     self.lookback,
                                                     self.steps,
                                                     raw_data[train_indices]['AP ID'])

            X_train, X_validation, y_train, y_validation, ap_train, ap_validation = train_test_split(not_split_train_data[0],
                                                                            not_split_train_data[1],
                                                                            not_split_train_data[2],
                                                                            test_size=0.2,
                                                                            random_state=random_seed)

            X_test, y_test, ap_test = transform_dataset(np.array(timeseries[test_indices]).astype(np.float32), self.lookback,
                                               self.steps, raw_data[test_indices]['AP ID'])

        elif split_by == 'Index':
            column_unique_values = np.unique(raw_data[split_by])
            train_num = int(train_ratio)
            if train_ratio < 1:
                train_num = int(train_ratio * len(column_unique_values))
            not_split_train_data = transform_dataset(np.array(raw_data[columns]).astype(np.float32),
                                                     self.lookback,
                                                     self.steps,
                                                     raw_data['AP ID'])

            X_train, X_test, y_train, y_test, ap_train, ap_test = train_test_split(not_split_train_data[0],
                                                                not_split_train_data[1],
                                                                not_split_train_data[2],
                                                                train_size=train_num,
                                                                random_state=random_seed)

            X_train, X_validation, y_train, y_validation, ap_train, ap_validation  = train_test_split(X_train,
                                                                            y_train,
                                                                            ap_train,
                                                                            test_size=0.2,
                                                                            random_state=random_seed)

        print("      - APs for training/validation: " + str(train_aps))
        print("      - APs for test: " + str(test_aps))
        print("      - Training samples: " + str(len(X_train)))
        print("      - Validation samples: " + str(len(X_validation)))
        print("      - Test samples: " + str(len(X_test)))

        # STEP 3: Transform the dataset (normalization + time series creation)
        # Transform the dataset (normalization + time series creation)
        self.X_train, self.y_train, self.ap_train = X_train, y_train, ap_train
        self.X_validation, self.y_validation, self.ap_validation = X_validation, y_validation, ap_validation
        self.X_test, self.y_test, self.ap_test = X_test, y_test, ap_test

    def getSplit(self, split):
        if split == 'train':
            return self.X_train, self.y_train, self.ap_train
        if split == 'test':
            return self.X_test, self.y_test, self.ap_test
        return self.X_validation, self.y_validation, self.ap_validation

def load_dataset(path):
    # Load the dataset from a pickle file
    try:
        raw_data = pickle.load(open(path, "rb"))
        raw_data.insert(0, 'Index', range(0, len(raw_data)))
        raw_data = raw_data.reset_index()
    except FileNotFoundError:
        download_dataset()

    # Add the day of the week and the hour of the day to the time series
    raw_data['day_of_week'] = raw_data.datetime.dt.dayofweek
    raw_data['day_of_week_sin'] = np.sin(
        raw_data['day_of_week'] * (2 * np.pi / raw_data['day_of_week'].max()))
    raw_data['day_of_week_cos'] = np.cos(
        raw_data['day_of_week'] * (2 * np.pi / raw_data['day_of_week'].max()))
    raw_data['hour_of_day'] = raw_data.datetime.dt.hour
    raw_data['hour_of_day_sin'] = np.sin(
        raw_data['hour_of_day'] * (2 * np.pi / raw_data['hour_of_day'].max()))
    raw_data['hour_of_day_cos'] = np.cos(
        raw_data['hour_of_day'] * (2 * np.pi / raw_data['hour_of_day'].max()))

    return raw_data


def transform_dataset(dataset, lookback, steps, apIdColumn):
    scaler = preprocessing.MinMaxScaler(feature_range=(0.0001, 1))
    x = scaler.fit_transform(dataset)
    y = np.digitize(dataset[:, 0], bins=[1000, 100000])
    #y = scaler.transform(dataset)
    unique_aps = np.unique(apIdColumn)
    x_transform, y_transform, ap_transform = [], [], []
    for ap in unique_aps:
        x_transform_ap, y_transform_ap = time_series_generator(x[apIdColumn == ap], y[apIdColumn == ap], lookback,
                                                               steps)
        ap_transform.extend([ap] * len(x_transform_ap))
        if len(x_transform) == 0:
            x_transform, y_transform = x_transform_ap, y_transform_ap
        else:
            x_transform, y_transform = np.concatenate((x_transform, x_transform_ap), axis=0), np.concatenate(
                (y_transform, y_transform_ap), axis=0)

    return x_transform, y_transform.squeeze(), ap_transform


def download_dataset():
    # METHOD TO BE IMPLEMENTED:
    # - If the dataset is not locally, it should be downloaded from a URL (an example below)
    # URL = 'http...'
    # file_path_local = './local_path/file_name.pkl'
    # # Download the file and save it locally to
    # urllib.request.urlretrieve(URL, file_path_local)
    # # Load the dataset
    # raw_data = pd.read_pickle(file_path_local)
    # return raw_data
    print("The ``download dataset`` functionality is not available. Please, download the dataset manually and save it"
          " to the corresponding folder (e.g., /data/flags/...")
    sys.exit(1)


def get_data_loader(dataset, batch_size, shuffle):
    """
    Get a data loader using the Dataset class

    Parameters:
        dataset: Dataset class object containing the dataset
        batch_size (int): batch size
        shuffle (bool): if the data should be shuffled
    """

    return torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)  # , loaded_data


if __name__ == '__main__':
    dataset_generator = DatasetGenerator(path='/home/dsalami/dataset/aggregated/pickle_2019-05-13-on7_2min.pkl', split_by='AP ID',
                                         train_ratio=50, test_ratio=16,
                                         lookback=60,
                                         steps=1, random_seed=None)
