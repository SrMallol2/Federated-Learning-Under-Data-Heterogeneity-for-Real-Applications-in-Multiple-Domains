from tqdm import trange
import numpy as np
import random
import json
import os
import argparse
from torchvision.datasets import MNIST
import torch
from torch.utils.data import DataLoader
import torchvision.transforms as transforms

from data.Flags.dataset import DatasetGenerator

random.seed(42)
np.random.seed(42)

def rearrange_data_by_ap(data, targets, aps):
    new_data, new_targets = {}, {}
    for ap in np.unique(aps):
        new_data[ap] = data[np.array(aps) == ap]
        new_targets[ap] = targets[np.array(aps) == ap]
    return new_data, new_targets

def get_number_of_samples(data):
    n_samples = 0
    for _, value in data.items():
        n_samples += len(value)
    return n_samples

def devide_train_data(data, targets, SRC_APS, NUM_USERS, min_sample, alpha=0.5, sampling_ratio=0.5):
    min_sample = 10#len(SRC_APS) * min_sample
    min_size = 0 # track minimal samples per user
    n_sample = get_number_of_samples(data)
    ###### Determine Sampling #######
    while min_size < min_sample:
        print('Try to find valid data separation')
        idx_batch=[{} for _ in range(NUM_USERS)]
        samples_per_user = [0 for _ in range(NUM_USERS)]
        max_samples_per_user = sampling_ratio * n_sample / NUM_USERS
        for l in SRC_APS:
            # get indices for all that AP
            idx_l = [i for i in range(len(data[l]))]
            np.random.shuffle(idx_l)
            if sampling_ratio < 1:
                samples_for_l = int( min(max_samples_per_user, int(sampling_ratio * len(data[l]))) )
                idx_l = idx_l[:samples_for_l]
                print(l, len(data[l]), len(idx_l))
            # dirichlet sampling from this label
            proportions=np.random.dirichlet(np.repeat(alpha, NUM_USERS))
            # re-balance proportions
            proportions=np.array([p * (n_per_user < max_samples_per_user) for p, n_per_user in zip(proportions, samples_per_user)])
            proportions=proportions / proportions.sum()
            proportions=(np.cumsum(proportions) * len(idx_l)).astype(int)[:-1]
            # participate data of that label
            for u, new_idx in enumerate(np.split(idx_l, proportions)):
                # add new idex to the user
                idx_batch[u][l] = new_idx.tolist()
                samples_per_user[u] += len(idx_batch[u][l])
        min_size=min(samples_per_user)

    ###### CREATE USER DATA SPLIT #######
    X = [[] for _ in range(NUM_USERS)]
    y = [[] for _ in range(NUM_USERS)]
    Labels=[set() for _ in range(NUM_USERS)]
    print('processing users...')
    for u, user_idx_batch in enumerate(idx_batch):
        for l, indices in user_idx_batch.items():
            if len(indices) == 0: continue
            X[u] += data[l][indices].tolist()
            y[u] += targets[l][indices].tolist()
            Labels[u].add(l)

    return X, y, Labels, idx_batch, samples_per_user

def divide_test_data(NUM_USERS, SRC_APS, test_data, targets, Labels, unknown_test):
    # Create TEST data for each user.
    test_X = [[] for _ in range(NUM_USERS)]
    test_y = [[] for _ in range(NUM_USERS)]
    idx = {l: 0 for l in SRC_APS}
    for user in trange(NUM_USERS):
        if unknown_test: # use all available labels
            user_sampled_labels = SRC_APS
        else:
            user_sampled_labels =  list(Labels[user])
        for l in user_sampled_labels:
            num_samples = int(len(test_data[l]) / NUM_USERS )
            assert num_samples + idx[l] <= len(test_data[l])
            test_X[user] += test_data[l][idx[l]:idx[l] + num_samples].tolist()
            test_y[user] += targets[l][idx[l]:idx[l] + num_samples].tolist()
            assert len(test_X[user]) == len(test_y[user]), f'{len(test_X[user])} == {len(test_y[user])}'
            idx[l] += num_samples
    return test_X, test_y

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--format', '-f', type=str, default='pt', help='Format of saving: pt (torch.save), json', choices=['pt', 'json'])
    parser.add_argument('--min_sample', type=int, default=10, help='Min number of samples per user.')
    parser.add_argument('--sampling_ratio', type=float, default=0.05, help='Ratio for sampling training samples.')
    parser.add_argument('--alpha', type=float, default=0.0001, help='alpha in Dirichelt distribution (smaller means larger heterogeneity)')
    parser.add_argument('--n_user', type=int, default=20,
                        help='number of local clients, should be muitiple of 10.')
    parser.add_argument("--unknown_test", type=int, default=0, help="Whether allow test APs unseen for each user.")
    parser.add_argument('--dataset_path', default='/home/dsalami/dataset/aggregated/pickle_2019-05-13-on7_2min.pkl',
                        help='Dataset path')
    parser.add_argument('--split_by', default='AP ID',
                        help='Determines the means of split for test and train. It should be a column in the dataset.')
    parser.add_argument('--train_ratio', type=float, default=50, help='Training dataset ratio')
    parser.add_argument('--test_ratio', type=float, default=16, help='Test dataset ratio')
    parser.add_argument('--lookback', type=int, default=60,
                        help='Number of past samples in the time series [default: 5]')
    parser.add_argument('--steps', type=int, default=1, help='Number of future samples in time series [default: 1]')
    parser.add_argument('--random_seed', type=int, default=None, help='Random seed for the split [default: None]')
    args = parser.parse_args()
    print()
    print('Dataset path: {}'.format(args.dataset_path))
    print('Lookback: {}'.format(args.lookback))
    print('Steps: {}'.format(args.steps))
    print('Number of users: {}'.format(args.n_user))
    print('Min # of samples per user: {}'.format(args.min_sample))
    print('Alpha for Dirichlet Distribution: {}'.format(args.alpha))
    print('Ratio for Sampling Training Data: {}'.format(args.sampling_ratio))
    NUM_USERS = args.n_user

    # Setup directory for train/test data
    path_prefix = f'u{args.n_user}-alpha{args.alpha}-ratio{args.sampling_ratio}'

    def process_user_data(mode, data, targets, SRC_APS, Labels=None, unknown_test=0):
        if mode == 'train':
            X, y, Labels, idx_batch, samples_per_user  = devide_train_data(
                data, targets, SRC_APS, NUM_USERS, args.min_sample, args.alpha, args.sampling_ratio)
        if mode == 'test':
            assert Labels != None or unknown_test
            X, y = divide_test_data(NUM_USERS, SRC_APS, data, targets, Labels, unknown_test)
        dataset={'users': [], 'user_data': {}, 'num_samples': []}
        for i in range(NUM_USERS):
            uname='f_{0:05d}'.format(i)
            dataset['users'].append(uname)
            dataset['user_data'][uname]={
                'x': torch.tensor(X[i], dtype=torch.float32),
                'y': torch.tensor(y[i], dtype=torch.float32)}
            dataset['num_samples'].append(len(X[i]))

        print('{} #sample by user:'.format(mode.upper()), dataset['num_samples'])

        data_path=f'./{path_prefix}/{mode}'
        if not os.path.exists(data_path):
            os.makedirs(data_path)

        data_path=os.path.join(data_path, '{}.'.format(mode) + args.format)
        if args.format == 'json':
            raise NotImplementedError(
                'json is not supported because the train_data/test_data uses the tensor instead of list and tensor cannot be saved into json.')
        elif args.format == 'pt':
            with open(data_path, 'wb') as outfile:
                print(f'Dumping train data => {data_path}')
                torch.save(dataset, outfile)
        if mode == 'train':
            for u in range(NUM_USERS):
                print('{} samples in total'.format(samples_per_user[u]))
                train_info = ''
                # train_idx_batch, train_samples_per_user
                n_samples_for_u = 0
                for l in sorted(list(Labels[u])):
                    n_samples_for_l = len(idx_batch[u][l])
                    n_samples_for_u += n_samples_for_l
                    train_info += 'c={},n={}| '.format(l, n_samples_for_l)
                print(train_info)
                print('{} Labels/ {} Number of training samples for user [{}]:'.format(len(Labels[u]), n_samples_for_u, u))
            return Labels, idx_batch, samples_per_user


    print(f'Reading source dataset.')
    dataset_generator = DatasetGenerator(path=args.dataset_path, split_by=args.split_by,
                                      train_ratio=args.train_ratio, test_ratio=args.test_ratio,
                                      lookback=args.lookback,
                                      steps=args.steps, random_seed=args.random_seed)
    train_data, train_target, train_ap = dataset_generator.getSplit('train')
    validation_data, validation_target, validation_ap = dataset_generator.getSplit('validation')
    train_data, train_target = rearrange_data_by_ap(train_data, train_target, train_ap)
    validation_data, validation_target = rearrange_data_by_ap(validation_data, validation_target, validation_ap)
    print('{} train APs in total.'.format(len(np.unique(train_ap))))
    print('{} validation APs in total.'.format(len(np.unique(validation_ap))))
    Labels, idx_batch, samples_per_user = process_user_data('train', train_data, train_target, np.unique(train_ap))
    process_user_data('test', validation_data, validation_target, np.unique(validation_ap), Labels=Labels, unknown_test=args.unknown_test)
    print('Finish Generating User samples')

if __name__ == '__main__':
    main()